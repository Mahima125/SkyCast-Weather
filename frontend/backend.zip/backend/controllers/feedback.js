const postFeedback = async (req, res) => {
  const { name, email, message } = req.body;
  console.log("Received form data:", {
    name,
    email,
    message,
  });
  var newFeedback = new Feedback({ name, email, message });
  newFeedback
    .save()
    .then(() => {
      console.log("Feedback saved");
      res.status(201).send(newFeedback);
    })
    .catch((err) => {
      console.error("Error saving user to database:", err);
    });
};

module.exports = { postFeedback };
