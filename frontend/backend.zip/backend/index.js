var express = require("express");
const cors = require("cors");
require("dotenv").config();

var app = express();

//db
const connectDb = require("./db/connect");

app.use(cors());
app.set("trust proxy", 1);
app.use(express.json());

//Routes
const authRouter = require("./routes/auth");
const feedbackRouter = require("./routes/feedback");
const authenticatedUser = require("./middleware/authentication");

app.use("/auth", authRouter);
app.use("/feedback", authenticatedUser, feedbackRouter);

const start = async () => {
  try {
    await connectDb(
      "mongodb+srv://Shyam:Shyam53@cluster0.hovanpm.mongodb.net/mahima?retryWrites=true&w=majority&appName=Cluster0"
    );
    app.listen(3000, () => console.log("Server is listening on port 3000"));
  } catch (error) {
    console.log(error);
  }
};

start();
